var firebaseConfig = {
    apiKey: "AIzaSyDaTOCoOoOz8cmqSVpN8TBbT0GSjB34Kmc",
    authDomain: "todorectobase.firebaseapp.com",
    projectId: "todorectobase",
    storageBucket: "todorectobase.appspot.com",
    messagingSenderId: "752707743576",
    appId: "1:752707743576:web:e0e5d6b999d06f0fd83f2d"
};
firebase.initializeApp(firebaseConfig);

